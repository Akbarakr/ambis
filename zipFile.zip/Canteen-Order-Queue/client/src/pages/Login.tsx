import { useState } from "react";
import { useAuth, useSendOtp, useVerifyOtp, useAdminLogin, useUpdateProfile } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { ChefHat, GraduationCap, ArrowRight, Phone, Lock, Mail, User } from "lucide-react";

type Step = 'select' | 'student-mobile' | 'student-otp' | 'student-profile' | 'admin-login';

export default function Login() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [step, setStep] = useState<Step>('select');
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [demoOtp, setDemoOtp] = useState("");

  const sendOtp = useSendOtp();
  const verifyOtp = useVerifyOtp();
  const adminLogin = useAdminLogin();
  const updateProfile = useUpdateProfile();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  // Only redirect if user exists AND we're not in profile update step
  if (user && step !== 'student-profile') {
    setLocation(user.role === 'admin' ? '/shop' : '/menu');
    return null;
  }

  const handleSendOtp = async () => {
    if (mobile.length < 10) {
      toast({ title: "Invalid Mobile", description: "Please enter a valid mobile number", variant: "destructive" });
      return;
    }
    try {
      const result = await sendOtp.mutateAsync(mobile);
      setDemoOtp(result.otp); // Demo only - remove in production
      toast({ title: "OTP Sent", description: `OTP sent to ${mobile}` });
      setStep('student-otp');
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleVerifyOtp = async () => {
    if (otp.length !== 6) {
      toast({ title: "Invalid OTP", description: "OTP must be 6 digits", variant: "destructive" });
      return;
    }
    try {
      const result = await verifyOtp.mutateAsync({ mobile, otp });
      if (result.needsProfileUpdate) {
        setStep('student-profile');
      } else {
        toast({ title: "Welcome back!", description: "Login successful" });
        setLocation('/menu');
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleUpdateProfile = async () => {
    if (!name.trim()) {
      toast({ title: "Name Required", description: "Please enter your name", variant: "destructive" });
      return;
    }
    try {
      await updateProfile.mutateAsync({ name, email: email || undefined });
      toast({ title: "Welcome!", description: "Profile updated successfully" });
      setLocation('/menu');
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleAdminLogin = async () => {
    if (!mobile || !password) {
      toast({ title: "Error", description: "Please enter mobile and password", variant: "destructive" });
      return;
    }
    try {
      await adminLogin.mutateAsync({ mobile, password });
      toast({ title: "Welcome Admin!", description: "Login successful" });
      setLocation('/shop');
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 dark:from-zinc-900 dark:to-zinc-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl mb-4 shadow-lg">
            <ChefHat className="h-8 w-8 text-primary-foreground" />
          </div>
          <h1 className="font-display font-bold text-3xl text-foreground">Ambi's cafe</h1>
          <p className="text-muted-foreground mt-2">Pre-order your favorite meals</p>
        </div>

        {step === 'select' && (
          <div className="space-y-4">
            <Card 
              className="cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 border-2 hover:border-primary"
              onClick={() => setStep('student-mobile')}
              data-testid="card-student-login"
            >
              <CardContent className="p-6 flex items-center gap-4">
                <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-xl">
                  <GraduationCap className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">Student Login</h3>
                  <p className="text-sm text-muted-foreground">Login with mobile number & OTP</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground" />
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 border-2 hover:border-primary"
              onClick={() => setStep('admin-login')}
              data-testid="card-admin-login"
            >
              <CardContent className="p-6 flex items-center gap-4">
                <div className="bg-orange-100 dark:bg-orange-900/30 p-3 rounded-xl">
                  <ChefHat className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">Admin Login</h3>
                  <p className="text-sm text-muted-foreground">Shopkeeper access with password</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground" />
              </CardContent>
            </Card>
          </div>
        )}

        {step === 'student-mobile' && (
          <Card>
            <CardHeader>
              <CardTitle>Student Login</CardTitle>
              <CardDescription>Enter your mobile number to receive OTP</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="mobile">Mobile Number</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="mobile"
                    type="tel"
                    placeholder="Enter 10-digit mobile"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                    className="pl-10"
                    data-testid="input-mobile"
                  />
                </div>
              </div>
              <Button 
                className="w-full" 
                onClick={handleSendOtp}
                disabled={sendOtp.isPending || mobile.length < 10}
                data-testid="button-send-otp"
              >
                {sendOtp.isPending ? "Sending..." : "Send OTP"}
              </Button>
              <Button variant="ghost" className="w-full" onClick={() => setStep('select')}>
                Back
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 'student-otp' && (
          <Card>
            <CardHeader>
              <CardTitle>Verify OTP</CardTitle>
              <CardDescription>Enter the 6-digit OTP sent to {mobile}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {demoOtp && (
                <div className="bg-yellow-100 dark:bg-yellow-900/30 p-3 rounded-lg text-sm">
                  <span className="font-bold">Demo OTP:</span> {demoOtp}
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="otp">OTP</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="otp"
                    type="text"
                    placeholder="Enter 6-digit OTP"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="pl-10 text-center text-xl tracking-widest"
                    data-testid="input-otp"
                  />
                </div>
              </div>
              <Button 
                className="w-full" 
                onClick={handleVerifyOtp}
                disabled={verifyOtp.isPending || otp.length !== 6}
                data-testid="button-verify-otp"
              >
                {verifyOtp.isPending ? "Verifying..." : "Verify & Login"}
              </Button>
              <Button variant="ghost" className="w-full" onClick={() => { setStep('student-mobile'); setOtp(''); }}>
                Change Number
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 'student-profile' && (
          <Card>
            <CardHeader>
              <CardTitle>Complete Your Profile</CardTitle>
              <CardDescription>Please provide your details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="pl-10"
                    data-testid="input-name"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email (Optional)</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    data-testid="input-email"
                  />
                </div>
              </div>
              <Button 
                className="w-full" 
                onClick={handleUpdateProfile}
                disabled={updateProfile.isPending || !name.trim()}
                data-testid="button-save-profile"
              >
                {updateProfile.isPending ? "Saving..." : "Save & Continue"}
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 'admin-login' && (
          <Card>
            <CardHeader>
              <CardTitle>Admin Login</CardTitle>
              <CardDescription>Enter your credentials</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted/50 p-3 rounded-lg text-sm">
                <span className="font-bold">Demo:</span> Mobile: 9999999999, Password: admin123
              </div>
              <div className="space-y-2">
                <Label htmlFor="admin-mobile">Mobile Number</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="admin-mobile"
                    type="tel"
                    placeholder="Enter mobile number"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    className="pl-10"
                    data-testid="input-admin-mobile"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    data-testid="input-password"
                  />
                </div>
              </div>
              <Button 
                className="w-full" 
                onClick={handleAdminLogin}
                disabled={adminLogin.isPending}
                data-testid="button-admin-login"
              >
                {adminLogin.isPending ? "Logging in..." : "Login"}
              </Button>
              <Button variant="ghost" className="w-full" onClick={() => { setStep('select'); setMobile(''); setPassword(''); }}>
                Back
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
