import { useOrders, useUpdateOrderStatus } from "@/hooks/use-orders";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle2, Clock, XCircle, ShoppingBag } from "lucide-react";
import { format } from "date-fns";

export default function ShopDashboard() {
  const { data: orders, isLoading } = useOrders();
  const updateStatus = useUpdateOrderStatus();

  if (isLoading) return <div className="p-8">Loading dashboard...</div>;

  const pendingOrders = orders?.filter((o: any) => o.status === 'pending') || [];
  const activeOrders = orders?.filter((o: any) => ['confirmed', 'pending'].includes(o.status)) || [];
  const completedOrders = orders?.filter((o: any) => o.status === 'completed') || [];

  const handleStatusUpdate = (id: number, status: string, paymentStatus?: string) => {
    updateStatus.mutate({ id, status, paymentStatus });
  };

  const OrderList = ({ orders }: { orders: any[] }) => (
    <div className="grid gap-4">
      {orders.length === 0 && <div className="text-center p-8 text-muted-foreground">No orders in this category</div>}
      {orders.map((order) => (
        <Card key={order.id}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-bold">
              Order #{String(order.id).padStart(4, '0')}
            </CardTitle>
            <Badge variant={order.paymentStatus === 'paid' ? 'default' : 'secondary'}>
              {order.paymentStatus === 'paid' ? 'Paid' : 'Unpaid'} ({order.paymentMethod})
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-start mb-4">
              <div>
                <CardDescription>
                  {format(new Date(order.createdAt), "h:mm a")} • Total: ₹{Number(order.totalAmount).toFixed(0)}
                </CardDescription>
                {/* Items would be listed here if available in list response relation */}
                <div className="mt-2 text-sm">
                   {order.items?.length || 0} items
                </div>
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              {order.status === 'pending' && (
                <>
                  <Button 
                    size="sm" 
                    variant="destructive"
                    onClick={() => handleStatusUpdate(order.id, 'cancelled')}
                  >
                    Reject
                  </Button>
                  <Button 
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white" 
                    onClick={() => handleStatusUpdate(order.id, 'confirmed')}
                  >
                    Accept Order
                  </Button>
                </>
              )}
              {order.status === 'confirmed' && (
                <Button 
                  size="sm" 
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => handleStatusUpdate(order.id, 'completed', 'paid')}
                >
                  Mark Ready & Paid
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="container px-4 py-8 pb-24">
      <div className="grid gap-4 md:grid-cols-3 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Orders</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingOrders.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeOrders.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedOrders.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList>
          <TabsTrigger value="active">Active Orders</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        <TabsContent value="active" className="space-y-4">
          <OrderList orders={activeOrders} />
        </TabsContent>
        <TabsContent value="completed" className="space-y-4">
          <OrderList orders={completedOrders} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
